A C# SVG rendering engine, primarily designed to allow SVG files to be used on the web.

SVG is a language for describing two-dimensional graphics in XML {"[XML10](XML10)"}. SVG allows for three types of graphic objects: vector graphic shapes (e.g., paths consisting of straight lines and curves), images and text. Graphical objects can be grouped, styled, transformed and composited into previously rendered objects. The feature set includes nested transformations, clipping paths, alpha masks, filter effects and template objects.

SVG stands for Scalable Vector Graphics, an XML  grammar for stylable graphics, usable as an XML namespace (see [http://www.w3.org/TR/SVG11/concepts.html](http://www.w3.org/TR/SVG11/concepts.html)).

**Tutorials**
- [Building a Three-State Button](Building-a-Three-State-Button)

The Svg.dll assembly contains an IAsyncHttpHandler called Svg.Web.SvgHandler. This handler should be registered to handle all files with extension *.svg. It will read the file and then send the rendered image back to the browser in .png format.

**Why create a rendering engine? Firefox, Opera and Safari already support SVG!**

It's true that these browsers all support various levels of SVG but they don't all support it in a very useful way. It's not possible to simply add a CSS background style to use an SVG image or bullet point list image. Even if it were possible, our best friend Internet Explorer doesn't support SVG (and I don't know when or _if_ it will be in their roadmap).

This software has been designed to allow web application developers to start using SVG files _now_. When all browsers support this format the handler can simply be removed.

**Why not just use Silverlight?**

This project is not aimed at replacing Silverlight/XAML or any other technology. It's here to allow developers to use SVG for images. If your requirements at that the graphics must be dynamic and interact with the DOM then Silverlight is for you; if all you want to do is easily edit an image then this software might be what you want.